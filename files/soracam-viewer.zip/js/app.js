/**
 * SORACam Viewer
 * S3バケットに保存されたSORACOMカメラの画像を表示するアプリケーション
 */

document.addEventListener('DOMContentLoaded', function() {
    // 定数
    const REGION = 'ap-northeast-1'; // 東京リージョン
    const DEFAULT_FOLDER = 'live-camera';
    
    // DOM要素
    const bucketNameInput = document.getElementById('bucket-name');
    const datetimePicker = document.getElementById('datetime-picker');
    const refreshBtn = document.getElementById('refresh-btn');
    const imageDisplay = document.getElementById('image-display');
    const settingsForm = document.getElementById('settings-form');
    
    // Flatpickrの初期化
    const picker = flatpickr(datetimePicker, {
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        time_24hr: true,
        minuteIncrement: 1,
        defaultDate: new Date(),
        locale: {
            firstDayOfWeek: 0,
            weekdays: {
                shorthand: ['日', '月', '火', '水', '木', '金', '土'],
                longhand: ['日曜日', '月曜日', '火曜日', '水曜日', '木曜日', '金曜日', '土曜日']
            },
            months: {
                shorthand: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
                longhand: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
            }
        }
    });
    
    // ローカルストレージからバケット名を取得
    const savedBucketName = localStorage.getItem('soracam-bucket-name');
    if (savedBucketName) {
        bucketNameInput.value = savedBucketName;
    }
    
    // バケット名をローカルストレージに保存する関数
    function saveBucketName(bucketName) {
        if (bucketName) {
            localStorage.setItem('soracam-bucket-name', bucketName);
        }
    }
    
    // 日時からファイル名を生成
    function generateObjectKey(datetime) {
        const date = new Date(datetime);
        
        // 日本時間に調整（UTCからの時差を考慮）
        const jpDate = new Date(date.getTime() + (9 * 60 * 60 * 1000));
        
        const year = jpDate.getUTCFullYear();
        const month = String(jpDate.getUTCMonth() + 1).padStart(2, '0');
        const day = String(jpDate.getUTCDate()).padStart(2, '0');
        const hours = String(jpDate.getUTCHours()).padStart(2, '0');
        const minutes = String(jpDate.getUTCMinutes()).padStart(2, '0');
        
        return `${DEFAULT_FOLDER}/${year}${month}${day}_${hours}${minutes}.jpg`;
    }
    
    // 画像を表示
    function displayImage(imageUrl) {
        imageDisplay.innerHTML = '';
        const img = document.createElement('img');
        img.src = imageUrl;
        img.alt = '監視カメラ画像';
        img.onload = function() {
            imageDisplay.appendChild(img);
        };
        img.onerror = function() {
            showError('画像の読み込みに失敗しました');
        };
    }
    
    // エラーメッセージを表示
    function showError(message) {
        imageDisplay.innerHTML = `<p class="error-message">${message}</p>`;
    }
    
    // 読み込み中メッセージを表示
    function showLoading() {
        imageDisplay.innerHTML = '<p class="loading">画像を読み込み中...</p>';
    }
    
    // 直接URLを生成
    function generateDirectUrl(bucketName, objectKey) {
        return `https://${bucketName}.s3.${REGION}.amazonaws.com/${objectKey}`;
    }
    
    // 画像を取得
    function fetchImage() {
        const bucketName = bucketNameInput.value.trim();
        if (!bucketName) {
            showError('S3バケット名を入力してください');
            return;
        }
        
        const datetime = datetimePicker.value;
        if (!datetime) {
            showError('日時を選択してください');
            return;
        }
        
        // バケット名を保存
        saveBucketName(bucketName);
        
        const objectKey = generateObjectKey(datetime);
        showLoading();
        
        // 直接URLでアクセス
        const directUrl = generateDirectUrl(bucketName, objectKey);
        
        // 画像の存在を確認
        const img = new Image();
        img.onload = function() {
            displayImage(directUrl);
        };
        img.onerror = function() {
            showError(`指定された日時（${datetime}）の画像が見つかりませんでした`);
        };
        img.src = directUrl;
    }
    
    // 最新の画像を取得
    function fetchLatestImage() {
        const bucketName = bucketNameInput.value.trim();
        if (!bucketName) {
            showError('S3バケット名を入力してください');
            return;
        }
        
        // バケット名を保存
        saveBucketName(bucketName);
        
        showLoading();
        
        // 現在の日時から最新の画像を推測
        const now = new Date();
        // 日本時間に調整（UTCからの時差を考慮）
        const jstNow = new Date(now.getTime() + (9 * 60 * 60 * 1000));
        
        // 過去1時間の画像を試す（5分間隔で12枚）
        const attempts = [];
        for (let i = 0; i < 12; i++) {
            const attemptTime = new Date(jstNow.getTime() - i * 5 * 60 * 1000);
            const year = attemptTime.getUTCFullYear();
            const month = String(attemptTime.getUTCMonth() + 1).padStart(2, '0');
            const day = String(attemptTime.getUTCDate()).padStart(2, '0');
            const hours = String(attemptTime.getUTCHours()).padStart(2, '0');
            const minutes = String(Math.floor(attemptTime.getUTCMinutes() / 5) * 5).padStart(2, '0');
            
            const objectKey = `${DEFAULT_FOLDER}/${year}${month}${day}_${hours}${minutes}.jpg`;
            attempts.push(objectKey);
        }
        
        // 順番に画像の存在を確認
        tryNextImage(bucketName, attempts, 0);
    }
    
    // 画像を順番に試す
    function tryNextImage(bucketName, attempts, index) {
        if (index >= attempts.length) {
            showError('最新の画像が見つかりませんでした');
            return;
        }
        
        const objectKey = attempts[index];
        const directUrl = generateDirectUrl(bucketName, objectKey);
        
        const img = new Image();
        img.onload = function() {
            displayImage(directUrl);
            // 日時ピッカーを更新
            updateDatetimePicker(objectKey);
        };
        img.onerror = function() {
            // 次の画像を試す
            tryNextImage(bucketName, attempts, index + 1);
        };
        img.src = directUrl;
    }
    
    // 日時ピッカーを更新
    function updateDatetimePicker(objectKey) {
        // ファイル名から日時を抽出（例: live-camera/20250508_1530.jpg）
        const match = objectKey.match(/(\d{8})_(\d{4})\.jpg$/);
        if (match) {
            const dateStr = match[1]; // 20250508
            const timeStr = match[2]; // 1530
            
            const year = dateStr.substring(0, 4);
            const month = dateStr.substring(4, 6);
            const day = dateStr.substring(6, 8);
            const hour = timeStr.substring(0, 2);
            const minute = timeStr.substring(2, 4);
            
            const dateTimeStr = `${year}-${month}-${day} ${hour}:${minute}`;
            picker.setDate(dateTimeStr);
        }
    }
    
    // イベントリスナー
    settingsForm.addEventListener('submit', function(e) {
        e.preventDefault();
        fetchImage();
    });
    
    refreshBtn.addEventListener('click', function() {
        fetchLatestImage();
    });
    
    // 初期表示
    if (bucketNameInput.value) {
        fetchLatestImage();
    }
});