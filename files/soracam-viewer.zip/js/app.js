/**
 * SORACam Viewer
 * S3バケットに保存されたSORACOMカメラの画像を表示するアプリケーション
 */

document.addEventListener('DOMContentLoaded', function() {
    // 定数
    const REGION = 'ap-northeast-1'; // 東京リージョン
    
    // DOM要素
    const bucketNameInput = document.getElementById('bucket-name');
    const originalPrefixInput = document.getElementById('original-prefix');
    const analyzedPrefixInput = document.getElementById('analyzed-prefix');
    const datetimePicker = document.getElementById('datetime-picker');
    const refreshBtn = document.getElementById('refresh-btn');
    const originalImageDisplay = document.getElementById('original-image-display');
    const analyzedImageDisplay = document.getElementById('analyzed-image-display');
    const settingsForm = document.getElementById('settings-form');
    
    // Flatpickrの初期化
    const picker = flatpickr(datetimePicker, {
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        time_24hr: true,
        minuteIncrement: 1,
        defaultDate: new Date(),
        locale: {
            firstDayOfWeek: 0,
            weekdays: {
                shorthand: ['日', '月', '火', '水', '木', '金', '土'],
                longhand: ['日曜日', '月曜日', '火曜日', '水曜日', '木曜日', '金曜日', '土曜日']
            },
            months: {
                shorthand: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
                longhand: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
            }
        }
    });
    
    // ローカルストレージから設定を取得
    const savedBucketName = localStorage.getItem('soracam-bucket-name');
    const savedOriginalPrefix = localStorage.getItem('soracam-original-prefix');
    const savedAnalyzedPrefix = localStorage.getItem('soracam-analyzed-prefix');
    
    if (savedBucketName) {
        bucketNameInput.value = savedBucketName;
    }
    if (savedOriginalPrefix) {
        originalPrefixInput.value = savedOriginalPrefix;
    }
    if (savedAnalyzedPrefix) {
        analyzedPrefixInput.value = savedAnalyzedPrefix;
    }
    
    // 設定をローカルストレージに保存する関数
    function saveSettings(bucketName, originalPrefix, analyzedPrefix) {
        if (bucketName) {
            localStorage.setItem('soracam-bucket-name', bucketName);
        }
        if (originalPrefix) {
            localStorage.setItem('soracam-original-prefix', originalPrefix);
        }
        if (analyzedPrefix) {
            localStorage.setItem('soracam-analyzed-prefix', analyzedPrefix);
        }
    }
    
    // 日時からファイル名を生成
    function generateObjectKey(datetime, folder) {
        const date = new Date(datetime);
        
        // 日本時間に調整（UTCからの時差を考慮）
        const jpDate = new Date(date.getTime() + (9 * 60 * 60 * 1000));
        
        const year = jpDate.getUTCFullYear();
        const month = String(jpDate.getUTCMonth() + 1).padStart(2, '0');
        const day = String(jpDate.getUTCDate()).padStart(2, '0');
        const hours = String(jpDate.getUTCHours()).padStart(2, '0');
        const minutes = String(jpDate.getUTCMinutes()).padStart(2, '0');
        
        return `${folder}/${year}${month}${day}_${hours}${minutes}.jpg`;
    }
    
    // 画像を表示
    function displayImage(imageUrl, displayElement, isAnalyzed = false) {
        displayElement.innerHTML = '';
        
        // 直接imgタグを使用して画像を表示
        displayElement.innerHTML = `<img src="${imageUrl}" alt="${isAnalyzed ? '解析済み画像' : '元画像'}" style="max-width:100%;">`;
    }
    
    // エラーメッセージを表示
    function showError(message, displayElement) {
        displayElement.innerHTML = `<p class="error-message">${message}</p>`;
    }
    
    // 読み込み中メッセージを表示
    function showLoading(displayElement) {
        displayElement.innerHTML = '<p class="loading">画像を読み込み中...</p>';
    }
    
    // 直接URLを生成
    function generateDirectUrl(bucketName, objectKey) {
        return `https://${bucketName}.s3.${REGION}.amazonaws.com/${objectKey}`;
    }
    
    // 画像を取得
    function fetchImage() {
        const bucketName = bucketNameInput.value.trim();
        const originalPrefix = originalPrefixInput.value.trim();
        const analyzedPrefix = analyzedPrefixInput.value.trim();
        
        if (!bucketName) {
            showError('S3バケット名を入力してください', originalImageDisplay);
            showError('S3バケット名を入力してください', analyzedImageDisplay);
            return;
        }
        
        if (!originalPrefix) {
            showError('元画像プレフィックスを入力してください', originalImageDisplay);
            return;
        }
        
        if (!analyzedPrefix) {
            showError('解析済み画像プレフィックスを入力してください', analyzedImageDisplay);
            return;
        }
        
        const datetime = datetimePicker.value;
        if (!datetime) {
            showError('日時を選択してください', originalImageDisplay);
            showError('日時を選択してください', analyzedImageDisplay);
            return;
        }
        
        // 設定を保存
        saveSettings(bucketName, originalPrefix, analyzedPrefix);
        
        // 元画像と解析済み画像の両方を取得
        const originalObjectKey = generateObjectKey(datetime, originalPrefix);
        const analyzedObjectKey = generateObjectKey(datetime, analyzedPrefix);
        
        showLoading(originalImageDisplay);
        showLoading(analyzedImageDisplay);
        
        // 元画像を取得
        const originalUrl = generateDirectUrl(bucketName, originalObjectKey);
        const originalImg = new Image();
        originalImg.onload = function() {
            displayImage(originalUrl, originalImageDisplay, false);
            
            // 元画像が見つかったら、解析済み画像も確認
            const analyzedUrl = generateDirectUrl(bucketName, analyzedObjectKey);
            
            // デバッグ情報をコンソールに出力
            console.log('解析済み画像URL:', analyzedUrl);
            console.log('解析済み画像オブジェクトキー:', analyzedObjectKey);
            
            // 直接imgタグを使用して解析済み画像を表示（デバッグ情報なし）
            analyzedImageDisplay.innerHTML = `
                <img src="${analyzedUrl}" alt="解析済み画像" style="max-width:100%;">
            `;
        };
        originalImg.onerror = function() {
            showError(`指定された日時（${datetime}）の元画像が見つかりませんでした`, originalImageDisplay);
            showError('元画像が見つからないため、解析結果も表示できません', analyzedImageDisplay);
        };
        originalImg.src = originalUrl;
    }
    
    // 最新の画像を取得
    function fetchLatestImage() {
        const bucketName = bucketNameInput.value.trim();
        const originalPrefix = originalPrefixInput.value.trim();
        const analyzedPrefix = analyzedPrefixInput.value.trim();
        
        if (!bucketName) {
            showError('S3バケット名を入力してください', originalImageDisplay);
            showError('S3バケット名を入力してください', analyzedImageDisplay);
            return;
        }
        
        if (!originalPrefix) {
            showError('元画像プレフィックスを入力してください', originalImageDisplay);
            return;
        }
        
        if (!analyzedPrefix) {
            showError('解析済み画像プレフィックスを入力してください', analyzedImageDisplay);
            return;
        }
        
        // 設定を保存
        saveSettings(bucketName, originalPrefix, analyzedPrefix);
        
        showLoading(originalImageDisplay);
        showLoading(analyzedImageDisplay);
        
        // 現在の日時から最新の画像を推測
        const now = new Date();
        // 日本時間に調整（UTCからの時差を考慮）
        const jstNow = new Date(now.getTime() + (9 * 60 * 60 * 1000));
        
        // 過去1時間の画像を試す（5分間隔で12枚）
        const attempts = [];
        for (let i = 0; i < 12; i++) {
            const attemptTime = new Date(jstNow.getTime() - i * 5 * 60 * 1000);
            const year = attemptTime.getUTCFullYear();
            const month = String(attemptTime.getUTCMonth() + 1).padStart(2, '0');
            const day = String(attemptTime.getUTCDate()).padStart(2, '0');
            const hours = String(attemptTime.getUTCHours()).padStart(2, '0');
            const minutes = String(Math.floor(attemptTime.getUTCMinutes() / 5) * 5).padStart(2, '0');
            
            const objectKey = `${year}${month}${day}_${hours}${minutes}.jpg`;
            attempts.push(objectKey);
        }
        
        // 順番に画像の存在を確認
        tryNextImage(bucketName, attempts, 0);
    }
    
    // 画像を順番に試す
    function tryNextImage(bucketName, attempts, index) {
        if (index >= attempts.length) {
            showError('最新の画像が見つかりませんでした', originalImageDisplay);
            showError('最新の画像が見つかりませんでした', analyzedImageDisplay);
            return;
        }
        
        const baseObjectKey = attempts[index];
        const originalPrefix = originalPrefixInput.value.trim();
        const analyzedPrefix = analyzedPrefixInput.value.trim();
        const originalObjectKey = `${originalPrefix}/${baseObjectKey}`;
        const analyzedObjectKey = `${analyzedPrefix}/${baseObjectKey}`;
        
        const originalUrl = generateDirectUrl(bucketName, originalObjectKey);
        
        const img = new Image();
        img.onload = function() {
            // 元画像が見つかったら、元画像と解析済み画像の両方を表示
            displayImage(originalUrl, originalImageDisplay, false);
            
            // 解析済み画像を確認
            const analyzedUrl = generateDirectUrl(bucketName, analyzedObjectKey);
            
            // デバッグ情報をコンソールに出力
            console.log('最新画像検索 - 解析済み画像URL:', analyzedUrl);
            console.log('最新画像検索 - 解析済み画像オブジェクトキー:', analyzedObjectKey);
            
            // 直接imgタグを使用して解析済み画像を表示（デバッグ情報なし）
            analyzedImageDisplay.innerHTML = `
                <img src="${analyzedUrl}" alt="解析済み画像" style="max-width:100%;">
            `;
            
            // 日時ピッカーを更新
            updateDatetimePicker(originalObjectKey);
        };
        img.onerror = function() {
            // 次の画像を試す
            tryNextImage(bucketName, attempts, index + 1);
        };
        img.src = originalUrl;
    }
    
    // 日時ピッカーを更新
    function updateDatetimePicker(objectKey) {
        // ファイル名から日時を抽出（例: live-camera/20250508_1530.jpg）
        const match = objectKey.match(/(\d{8})_(\d{4})\.jpg$/);
        if (match) {
            const dateStr = match[1]; // 20250508
            const timeStr = match[2]; // 1530
            
            const year = dateStr.substring(0, 4);
            const month = dateStr.substring(4, 6);
            const day = dateStr.substring(6, 8);
            const hour = timeStr.substring(0, 2);
            const minute = timeStr.substring(2, 4);
            
            const dateTimeStr = `${year}-${month}-${day} ${hour}:${minute}`;
            picker.setDate(dateTimeStr);
        }
    }
    
    // イベントリスナー
    settingsForm.addEventListener('submit', function(e) {
        e.preventDefault();
        fetchImage();
    });
    
    refreshBtn.addEventListener('click', function() {
        fetchLatestImage();
    });
    
    // 初期表示
    if (bucketNameInput.value) {
        fetchLatestImage();
    }
});