# SORACam Viewer ハンズオン

このハンズオンでは、SORACOMのカメラ画像をAWS Lambdaを使ってS3に保存し、ウェブアプリから閲覧する仕組みを構築します。

## 前提条件

- AWSアカウント
- SORACOMアカウントとSORACOMカメラ
- 基本的なAWSサービスの知識

## ハンズオンの流れ

1. Lambda関数のデプロイ
2. S3バケットの設定
3. ウェブアプリのデプロイ（AWS Amplify）
4. 動作確認

## 1. Lambda関数のデプロイ

### 1.1 Lambda関数の作成

1. AWSマネジメントコンソールにログインし、Lambda サービスに移動します
2. 「関数の作成」をクリックします
3. 「一から作成」を選択します
4. 以下の情報を入力します：
   - 関数名: `soracam-image-exporter`
   - ランタイム: `Python 3.9`
   - アーキテクチャ: `x86_64`
5. 「関数の作成」をクリックします

### 1.2 Lambda関数のコード入力

1. 関数コードのエディタに以下のコードをコピー＆ペーストします：

```python
import json
import os
import time
import datetime
import urllib.request
import urllib.parse
import boto3

# 環境変数の取得
AUTH_KEY_ID = os.environ['authKeyId']
AUTH_KEY = os.environ['authKey']
DEVICE_ID = os.environ['device_id']
S3_BUCKET = os.environ['s3_bucket']
S3_FOLDER = 'live-camera'

def lambda_handler(event, context):
    try:
        # 1. 認証してAPIキーとトークンを取得する
        auth_response = authenticate()
        api_key = auth_response['apiKey']
        api_token = auth_response['token']

        # 2. 画像のエクスポートをリクエストする
        export_id = request_image_export(api_key, api_token)
    
        # 3. エクスポートの進捗を確認する
        image_url = check_export_status(api_key, api_token, export_id)

        # 4. S3に画像を保存する
        save_image_to_s3(image_url)
    
        return {
            'statusCode': 200,
            'body': json.dumps('Image successfully saved to S3')
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }

# 認証を行い、APIキーとトークンを取得
def authenticate():
    url = 'https://api.soracom.io/v1/auth'
    headers = {
        'Content-Type': 'application/json'
    }
    data = json.dumps({
        'authKeyId': AUTH_KEY_ID,
        'authKey': AUTH_KEY
    }).encode('utf-8')

    req = urllib.request.Request(url, headers=headers, data=data, method='POST')
    with urllib.request.urlopen(req) as response:
        if response.status != 200:
            raise Exception(f'Authentication failed: {response.status}')
        return json.loads(response.read().decode('utf-8'))

# 画像エクスポートをリクエストする
def request_image_export(api_key, api_token):
    url = f'https://api.soracom.io/v1/sora_cam/devices/{DEVICE_ID}/images/exports'
    headers = {
        'Content-Type': 'application/json',
        'X-Soracom-API-Key': api_key,
        'X-Soracom-Token': api_token
    }
    current_time = int(time.time() * 1000)  # 現在のUNIXタイムスタンプ（ミリ秒）
    data = json.dumps({'time': current_time}).encode('utf-8')

    req = urllib.request.Request(url, headers=headers, data=data, method='POST')
    with urllib.request.urlopen(req) as response:
        if response.status != 200:
            raise Exception(f'Image export request failed: {response.status}')
        export_response = json.loads(response.read().decode('utf-8'))
        return export_response['exportId']

# エクスポートの進捗を確認する
def check_export_status(api_key, api_token, export_id):
    url = f'https://api.soracom.io/v1/sora_cam/devices/{DEVICE_ID}/images/exports/{export_id}'
    headers = {
        'Content-Type': 'application/json',
        'X-Soracom-API-Key': api_key,
        'X-Soracom-Token': api_token
    }

    retry_intervals = [1, 2, 4]  # リトライの間隔
    for interval in retry_intervals:
        req = urllib.request.Request(url, headers=headers, method='GET')
        with urllib.request.urlopen(req) as response:
            if response.status != 200:
                raise Exception(f'Check export status failed: {response.status}')
            status_response = json.loads(response.read().decode('utf-8'))
        
            # エクスポートが完了した場合はURLを返す
            if status_response['status'] == 'completed':
                return status_response['url']
    
        # エクスポートが完了していない場合はリトライ
        time.sleep(interval)

    raise Exception('Image export not completed within allowed retries')

# 画像をS3に保存する
def save_image_to_s3(image_url):
    # 画像データを取得
    req = urllib.request.Request(image_url, method='GET')
    with urllib.request.urlopen(req) as response:
        if response.status != 200:
            raise Exception(f'Failed to download image: {response.status}')
        image_data = response.read()

    # S3オブジェクト名を作成 (JST時刻)
    jst = datetime.timezone(datetime.timedelta(hours=9))
    current_time = datetime.datetime.now(jst)
    object_name = current_time.strftime('%Y%m%d_%H%M.jpg')

    # S3に画像をアップロード
    s3_client = boto3.client('s3')
    s3_client.put_object(
        Bucket=S3_BUCKET,
        Key=f'{S3_FOLDER}/{object_name}',
        Body=image_data,
        ContentType='image/jpeg'
    )
```

### 1.3 環境変数の設定

1. 「設定」タブをクリックします
2. 「環境変数」セクションで、以下の環境変数を設定します：
   - `authKeyId`: SORACOMの認証キーID
   - `authKey`: SORACOMの認証キー
   - `device_id`: SORACOMカメラのデバイスID
   - `s3_bucket`: 作成するS3バケット名

### 1.4 実行ロールの設定

1. 「設定」タブの「アクセス権限」セクションで、実行ロールをクリックします
2. 「アクセス権限の追加」→「インラインポリシーを作成」をクリックします
3. JSONエディタで以下のポリシーを入力します：

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:PutObject"
            ],
            "Resource": "arn:aws:s3:::YOUR_BUCKET_NAME/*"
        }
    ]
}
```

4. `YOUR_BUCKET_NAME`を実際のバケット名に置き換えます
5. 「ポリシーの確認」→「ポリシーの作成」をクリックします

### 1.5 Lambda関数のテスト

1. 「テスト」タブをクリックします
2. 「テストイベント」を作成します（空のJSONオブジェクト `{}` で構いません）
3. 「テスト」ボタンをクリックして関数をテストします
4. 実行結果が成功することを確認します

## 2. S3バケットの設定

### 2.1 S3バケットの作成

1. AWSマネジメントコンソールで、S3サービスに移動します
2. 「バケットを作成」をクリックします
3. 以下の情報を入力します：
   - バケット名: 任意の一意な名前（Lambda関数の環境変数と同じ名前）
   - リージョン: アジアパシフィック（東京）
4. 「パブリックアクセスをすべてブロック」のチェックを外します
5. 「バケットを作成」をクリックします

### 2.2 バケットポリシーの設定

1. 作成したバケットを選択し、「アクセス許可」タブをクリックします
2. 「バケットポリシー」セクションで「編集」をクリックします
3. 以下のポリシーを入力します：

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "PublicReadGetObject",
            "Effect": "Allow",
            "Principal": "*",
            "Action": "s3:GetObject",
            "Resource": "arn:aws:s3:::YOUR_BUCKET_NAME/*"
        }
    ]
}
```

4. `YOUR_BUCKET_NAME`を実際のバケット名に置き換えます
5. 「変更の保存」をクリックします

### 2.3 CORS設定

1. 「アクセス許可」タブの「クロスオリジンリソース共有（CORS）」セクションで「編集」をクリックします
2. 以下の設定を入力します：

```json
[
    {
        "AllowedHeaders": ["*"],
        "AllowedMethods": ["GET"],
        "AllowedOrigins": ["*"],
        "ExposeHeaders": []
    }
]
```

3. 「変更の保存」をクリックします

## 3. ウェブアプリのデプロイ（AWS Amplify）

### 3.1 アプリケーションのZIPファイルの準備

1. このハンズオンで提供されたZIPファイルをダウンロードします
2. ZIPファイルを解凍せずに保存しておきます

**重要**: AWS Amplifyでデプロイする際は、ZIPファイルの構造が重要です。ZIPファイルには最上位のフォルダではなく、直接ファイルとディレクトリが含まれている必要があります。

正しいZIP構造:
```
soracam-viewer.zip
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
└── ...
```

誤ったZIP構造:
```
soracam-viewer.zip
└── soracam-viewer/
    ├── index.html
    ├── css/
    │   └── style.css
    ├── js/
    │   └── app.js
    └── ...
```

独自にZIPファイルを作成する場合は、ディレクトリ内に移動してから、そのディレクトリ内のすべてのファイルをZIP圧縮してください：
```
cd soracam-viewer
zip -r ../soracam-viewer.zip .
```

### 3.2 AWS Amplifyでのデプロイ

1. AWSマネジメントコンソールで、AWS Amplifyサービスに移動します
2. 「新しいアプリを作成」→「ウェブアプリをホスティング」をクリックします
3. 「デプロイなしで開始」を選択します
4. アプリ名（例: `soracam-viewer`）を入力し、「確認」をクリックします
5. 「手動デプロイ」セクションで「参照」をクリックし、先ほどのZIPファイルを選択します
6. 「保存してデプロイ」をクリックします
7. デプロイが完了するまで待ちます（数分かかります）
8. デプロイが完了すると、Amplifyコンソールに表示されるURLからアプリにアクセスできます
   - 例: `https://main.xxxxxxxx.amplifyapp.com`（xは自動生成される文字列）

### 3.3 ローカルでの動作確認（オプション）

AWS Amplifyにデプロイする前に、ローカルで動作確認することもできます：

1. ZIPファイルを解凍します
2. 解凍したフォルダ内のindex.htmlをブラウザで開きます
   - Chromeの場合、ファイルを右クリックして「Chromeで開く」を選択
   - または、ブラウザのアドレスバーに`file:///パス/index.html`と入力
3. S3バケット名を入力し、日時を選択して動作確認します

**注意**: ローカル環境でS3にアクセスする場合、CORSエラーが発生する可能性があります。その場合は、AWS Amplifyへのデプロイをお勧めします。

## 4. 動作確認

1. AWS Amplifyのコンソールに表示されるURLをクリックしてアプリケーションを開きます
2. S3バケット名を入力します
3. 日時を選択して「表示」ボタンをクリックします
4. 選択した日時の画像が表示されることを確認します
5. 「最新の画像を表示」ボタンをクリックして、最新の画像が表示されることを確認します

## トラブルシューティング

### 画像が表示されない場合

1. S3バケット名が正しく入力されているか確認します
2. Lambda関数が正常に実行されているか確認します
3. S3バケットのアクセス許可設定を確認します
4. ブラウザのコンソールでエラーメッセージを確認します

#### 「Missing credentials in config」エラーについて

このエラーは以前のバージョンでAWS SDKの認証情報が見つからない場合に発生していました。現在のバージョンではAWS SDKを使用せず、直接URLでのアクセスのみを使用しているため、このエラーは発生しなくなりました。

アプリケーションは以下の方法で画像にアクセスします：
- **直接URL**：`https://バケット名.s3.ap-northeast-1.amazonaws.com/live-camera/YYYYMMDD_hhmm.jpg`

画像が表示されない場合の対処法：
1. S3バケットが完全に公開設定になっていることを確認します
2. バケットポリシーで全てのユーザーに読み取り権限が付与されていることを確認します
3. CORSの設定が正しく行われていることを確認します
4. バケット名が正しく入力されていることを確認します

### Lambda関数がエラーになる場合

1. 環境変数が正しく設定されているか確認します
2. SORACOMの認証情報が正しいか確認します
3. Lambda関数の実行ロールに適切なアクセス権限があるか確認します

### AWS Amplifyのデプロイでエラーが発生する場合

1. ZIPファイルが正しく作成されているか確認します
2. Amplifyコンソールのビルドログを確認します
3. デプロイが完了するまで待ちます（通常は数分程度）
4. デプロイ完了後、Amplifyコンソールに表示されるURLをクリックしてアクセスします
5. 「このページが見つかりません」などのエラーが表示される場合：
   - デプロイが完全に完了しているか確認します（ステータスが「成功」になっているか）
   - 正しいURLにアクセスしているか確認します（例: `https://main.xxxxxxxx.amplifyapp.com`）
   - ブラウザのキャッシュをクリアして再度アクセスしてみてください
   - Amplifyコンソールで「再デプロイ」を試してください
6. 特定のURLでエラーが発生する場合（例: `staging.xxxxxxxx.amplifyapp.com`）：
   - デフォルトでは「main」ブランチがデプロイされるため、URLは通常「main.xxxxxxxx.amplifyapp.com」となります
   - 「staging」などの異なるブランチ名を使用している場合は、そのブランチがデプロイされているか確認してください
   - Amplifyコンソールで「ドメイン管理」を確認し、正しいURLを使用しているか確認してください

## カスタマイズのヒント

- 画像の取得間隔を変更するには、Lambda関数をCloudWatchイベントでスケジュール実行するように設定します
- UIのデザインを変更するには、`style.css`ファイルを編集します
- 表示する画像の数を増やすには、`app.js`ファイルの`fetchLatestImage`関数を修正します